use File::Fetch;

$folder = $ARGV[$ARGV-1];
$ARGV.pop();

$groupID = $ARGV[$ARGV-1];
$ARGV.pop();

sub fetch {
  my ($id, $folder) = @_;
  
  my $url = "https://image.eveonline.com/types/$id/icon";
  my $ff = File::Fetch->new(uri => $url);
  my $file = $ff->fetch() or die $ff->error;
  rename "icon","$folder\\$id.png"
}

open(LIST, ">>", "$folder\\list");

while ($s = <>) {
  my ($id, $grid, $name) = split(",", $s);
  if ($grid == $groupID) {
    print("$id $name\n");
    print(LIST "$id $name\n");
    fetch($id, $folder);
  }
}

